var searchData=
[
  ['size_213',['size',['../structBuffer.html#a3d37b3ab0942c1222347f8de7520f9ef',1,'Buffer']]],
  ['stride_214',['stride',['../structVertexAttrib.html#aef250d71bce43e96a6efb9180f24d079',1,'VertexAttrib']]]
];
