var searchData=
[
  ['empty_239',['EMPTY',['../fwd_8hpp.html#a349a9cde14be8097df865ba0469c0ab2aba2b45bdc11e2a4a6e86aab2ac693cbb',1,'EMPTY():&#160;fwd.hpp'],['../fwd_8hpp.html#a21e038f5b8958e203d28bc4f18472352aba2b45bdc11e2a4a6e86aab2ac693cbb',1,'EMPTY():&#160;fwd.hpp']]]
];
