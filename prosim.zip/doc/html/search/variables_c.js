var searchData=
[
  ['roots_212',['roots',['../structModel.html#ac1fcef5b98a4c88e5fec3672180e85f1',1,'Model']]]
];
