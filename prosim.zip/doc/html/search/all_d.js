var searchData=
[
  ['read_5ftexture_88',['read_texture',['../gpu_8cpp.html#abf6cca928d7eb5a455aed9776b59aaee',1,'read_texture(Texture const &amp;texture, glm::vec2 uv):&#160;gpu.cpp'],['../gpu_8hpp.html#abf6cca928d7eb5a455aed9776b59aaee',1,'read_texture(Texture const &amp;texture, glm::vec2 uv):&#160;gpu.cpp']]],
  ['roots_89',['roots',['../structModel.html#ac1fcef5b98a4c88e5fec3672180e85f1',1,'Model']]]
];
